<?php return array('dependencies' => array(), 'version' => 'dfccca53c03e01ca94e5');
