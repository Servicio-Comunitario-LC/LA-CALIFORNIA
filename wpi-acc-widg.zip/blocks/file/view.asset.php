<?php return array('dependencies' => array(), 'version' => '498971a8a9512421f3b5');
